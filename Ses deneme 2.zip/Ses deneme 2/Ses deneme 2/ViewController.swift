//
//  ViewController.swift
//  Ses deneme 2
//
//  Created by Anıl Baran on 19.09.2019.
//  Copyright © 2019 Anıl Baran. All rights reserved.
//

import UIKit
import Speech
class ViewController: UIViewController ,SFSpeechRecognizerDelegate {

    
    @IBOutlet weak var colorview: UIView!
    @IBOutlet weak var detectedtextlabel: UILabel!
    
    @IBOutlet weak var startorstop: UIButton!
    let audioEngine = AVAudioEngine()
    let speecReconizer : SFSpeechRecognizer? = SFSpeechRecognizer(locale: Locale.init(identifier: "en-us"))
    let request = SFSpeechAudioBufferRecognitionRequest()
    var recognitionTask: SFSpeechRecognitionTask?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.requestSpeechAuthorization()

    }

    func recordAndRecognizeSpeech()  {
         let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.request.append(buffer)
        }
        
        audioEngine.prepare()
        do {
            try audioEngine.start()
            
        }catch {
        }
        
       guard let myReconizer = SFSpeechRecognizer() else {
            return
        }
        
        if !myReconizer.isAvailable {
            return
        }

        
        recognitionTask = speecReconizer?.recognitionTask(with: request, resultHandler: { (result, error) in
            print("test")
            if let result = result {
                let bestString = result.bestTranscription.formattedString
                self.detectedtextlabel.text = bestString
                var lastString : String = ""
                
                for segment in result.bestTranscription.segments {
                    let indexTo = bestString.index(bestString.startIndex, offsetBy: segment.substringRange.location)
                    
                    //lastString = bestString.substring(from: indexTo)
                    lastString = String(bestString[indexTo...]) // swift 4
                    
                }
                 self.checkForcolorSaid(resultString:lastString)
                
                
            }else if let error = error {
                print(error)
            }
        }

        )
        
       
    }
    
    
    func checkForcolorSaid(resultString:String) {
       
        
        switch resultString {
        case "orange":
            colorview.backgroundColor = UIColor.orange
            print("orange print")
            
        case "blue":
            colorview.backgroundColor = UIColor.blue
            print("blue print")
        case "black":
            colorview.backgroundColor = UIColor.black
            print("black yazdı")
        default:break
            
        }
    }
    

    
    func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case.authorized:
                    self.startorstop.isEnabled = true
                case.denied:
                    self.startorstop.isEnabled = false
                    self.detectedtextlabel.text = "User denied"
                
                case .restricted:
                    self.startorstop.isEnabled = false
                    self.detectedtextlabel.text = "Sppech rec res on thıs devcei"
                case.notDetermined:
                    self.startorstop.isEnabled = false
                    self.detectedtextlabel.text = "izin ver amın evladı"
                    
                @unknown default:
                    fatalError()
                }
            }
            
        }
        
        
        
        
    }
    
    
    
    @IBAction func startorstop(_ sender: Any) {
        
        if audioEngine.isRunning {
            audioEngine.stop()
            
            startorstop.setTitle("Start Recording", for: .normal)
        } else  {
         
            recordAndRecognizeSpeech()
            startorstop.setTitle("Stop Recording", for: .normal)
            
        }    }

        
        
        
    }
    
    


    
    
    


